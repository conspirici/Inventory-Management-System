import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.Date;

public class InventoryApp {

    // ===== MODEL =====
    public static class InventoryItem {
        private String name;
        private String category;
        private int quantity;
        private double price;
        private Date expiryDate;

        public InventoryItem(String name, String category, int quantity, double price, Date expiryDate) {
            this.name = name;
            this.category = category;
            this.quantity = quantity;
            this.price = price;
            this.expiryDate = expiryDate;
        }

        public String getName() { return name; }
        public String getCategory() { return category; }
        public int getQuantity() { return quantity; }
        public double getPrice() { return price; }
        public Date getExpiryDate() { return expiryDate; }
    }

    // ===== DAO =====
    public static class InventoryDAO {
        private static final String URL = "jdbc:mysql://localhost:3306/store";
        private static final String USER = "root";
        private static final String PASS = "password"; // Change this to your MySQL password

        public InventoryDAO() {
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
            } catch (ClassNotFoundException e) {
                System.err.println("JDBC Driver not found: " + e.getMessage());
            }
        }

        public boolean addItem(InventoryItem item) {
            String sql = "INSERT INTO inventory (name, category, quantity, price, expiry_date) VALUES (?, ?, ?, ?, ?)";
            try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
                 PreparedStatement stmt = conn.prepareStatement(sql)) {

                stmt.setString(1, item.getName());
                stmt.setString(2, item.getCategory());
                stmt.setInt(3, item.getQuantity());
                stmt.setDouble(4, item.getPrice());
                stmt.setDate(5, new java.sql.Date(item.getExpiryDate().getTime()));

                return stmt.executeUpdate() > 0;
            } catch (SQLException e) {
                System.err.println("Error inserting item: " + e.getMessage());
                return false;
            }
        }
    }

    // ===== VIEW =====
    public static class AddItemView extends JPanel {
        JTextField nameField = new JTextField(20);
        JTextField categoryField = new JTextField(20);
        JTextField quantityField = new JTextField(10);
        JTextField priceField = new JTextField(10);
        JSpinner expirySpinner;
        JButton addButton = new JButton("Add Item");

        public AddItemView() {
            setLayout(new GridBagLayout());
            GridBagConstraints gbc = new GridBagConstraints();
            gbc.fill = GridBagConstraints.HORIZONTAL;

            gbc.gridx = 0; gbc.gridy = 0;
            add(new JLabel("Name:"), gbc);
            gbc.gridx = 1;
            add(nameField, gbc);

            gbc.gridx = 0; gbc.gridy = 1;
            add(new JLabel("Category:"), gbc);
            gbc.gridx = 1;
            add(categoryField, gbc);

            gbc.gridx = 0; gbc.gridy = 2;
            add(new JLabel("Quantity:"), gbc);
            gbc.gridx = 1;
            add(quantityField, gbc);

            gbc.gridx = 0; gbc.gridy = 3;
            add(new JLabel("Price:"), gbc);
            gbc.gridx = 1;
            add(priceField, gbc);

            gbc.gridx = 0; gbc.gridy = 4;
            add(new JLabel("Expiry Date:"), gbc);
            gbc.gridx = 1;
            expirySpinner = new JSpinner(new SpinnerDateModel());
            expirySpinner.setEditor(new JSpinner.DateEditor(expirySpinner, "yyyy-MM-dd"));
            add(expirySpinner, gbc);

            gbc.gridx = 0; gbc.gridy = 5; gbc.gridwidth = 2;
            add(addButton, gbc);
        }
    }

    // ===== CONTROLLER =====
    public static class AddItemController {
        private AddItemView view;
        private InventoryDAO dao;

        public AddItemController(AddItemView view, InventoryDAO dao) {
            this.view = view;
            this.dao = dao;
            this.view.addButton.addActionListener(new AddButtonListener());
        }

        class AddButtonListener implements ActionListener {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    String name = view.nameField.getText().trim();
                    String category = view.categoryField.getText().trim();
                    if (name.isEmpty() || category.isEmpty()) {
                        JOptionPane.showMessageDialog(view, "Name and Category cannot be empty.",
                                "Input Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }

                    int quantity;
                    try {
                        quantity = Integer.parseInt(view.quantityField.getText().trim());
                        if (quantity < 0) throw new NumberFormatException();
                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(view, "Quantity must be a non-negative integer.",
                                "Input Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }

                    double price;
                    try {
                        price = Double.parseDouble(view.priceField.getText().trim());
                        if (price < 0) throw new NumberFormatException();
                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(view, "Price must be a non-negative number.",
                                "Input Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }

                    Date expiry = (Date) view.expirySpinner.getValue();
                    InventoryItem item = new InventoryItem(name, category, quantity, price, expiry);
                    boolean success = dao.addItem(item);

                    if (success) {
                        JOptionPane.showMessageDialog(view, "Item added successfully!");
                        view.nameField.setText("");
                        view.categoryField.setText("");
                        view.quantityField.setText("");
                        view.priceField.setText("");
                        view.expirySpinner.setValue(new Date());
                    } else {
                        JOptionPane.showMessageDialog(view, "Failed to add item.",
                                "Database Error", JOptionPane.ERROR_MESSAGE);
                    }

                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(view, "Error: " + ex.getMessage(),
                            "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        }
    }

    // ===== MAIN =====
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            AddItemView view = new AddItemView();
            InventoryDAO dao = new InventoryDAO();
            new AddItemController(view, dao);

            JFrame frame = new JFrame("Add Item to Inventory");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.getContentPane().add(view);
            frame.pack();
            frame.setLocationRelativeTo(null);
            frame.setVisible(true);
        });
    }
}
